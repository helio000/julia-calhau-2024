#include <stdio.h>

int main() {
    char nome[50];
    int lucro, gastos;

    printf("Digite o nome: ");
    scanf("%s", nome);

    printf("Digite o valor dos ganhos: ");
    scanf("%d", &lucro);

    printf("Digite o valor dos gastos: ");
    scanf("%d", &gastos);

    int lucro_liquido = lucro - gastos;

    if (lucro_liquido > 0) {
        printf("A empresa teve lucro.\n");
    } else if (lucro_liquido < 0) {
        printf("teve prejuízo.\n");
    } else {
        printf(" não teve lucro nem prejuízo.\n");
    }

    return 0;
}