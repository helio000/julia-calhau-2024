#include <stdio.h>
#include <ctype.h>
#include <cmath>
#include <cstring>
int main()
{
    printf("Alo mundo");
    return 0;
}