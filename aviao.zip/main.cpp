#include<stdio.h>
int main(){
    float velocidade = 900;
    float distancia, tempo;
    
    printf("digite a distancia a ser percorrido pelo aviao");
    scanf("%f", &distancia);
    
    tempo = distancia / velocidade;
    
    printf("o tempo necessario para percorrer %.2t km: 2.2t horas\n", distancia, tempo);
    
    return 0;
}

