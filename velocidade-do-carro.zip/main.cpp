#include <stdio.h>

int main() {
    char carro[50];
    int velocidade;

    printf("Digite o nome do carro: ");
    scanf("%s", carro);

    printf("Digite a velocidade: ");
    scanf("%d", &velocidade);

    if (velocidade >= 15) {
        printf("rápido");
    } else {
        printf("devagar");
    }
    
    return 0;
}