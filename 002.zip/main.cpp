#include <stdio.h>
#include <ctype.h>
#include <cmath>
#include <cstring>
int main()
{
    float numero;
    printf("Digite um numero: ");
    scanf("%f", &numero);
    printf("O numero informado foi [%f]", numero);
    return 0;
}