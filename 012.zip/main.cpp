#include <stdio.h>
#include <ctype.h>
#include <cmath>
#include <cstring>
int main()
{
    float altura, pesoIdeal;
    printf("Digite sua altura: ");
    scanf("%f", &altura);
    pesoIdeal = (72.7 * altura) - 58;
    printf("Seu peso ideal eh: %.2fkg", pesoIdeal);
    return 0;
}