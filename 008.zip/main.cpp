#include <stdio.h>
#include <ctype.h>
#include <cmath>
#include <cstring>
int main()
{
    float salarioHr, salarioMe, horasTrabalhadas;
    printf("Digite quanto voce ganha por hora: ");
    scanf("%f", &salarioHr);
    printf("Digite quantas horas voce trabalhou esse mes: ");
    getchar();
    scanf("%f", &horasTrabalhadas);
    salarioMe = salarioHr * horasTrabalhadas;
    printf("Seu salario total do mes eh de R$%.2f", salarioMe);
    return 0;
}