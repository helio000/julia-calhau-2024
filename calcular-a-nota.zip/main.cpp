#include <stdio.h>
int main () {
    float nota1, nota2, media3;
    printf ("digite a nota 1:");
    scanf("%f", &nota1);
    
    printf ("digite nota2:");
    scanf("%f", &nota2);
    
    media3 =(nota1 + nota2)/2;
    
    printf("a media3 e: %1f", media3);
    
    if(media3>=5){
        
        printf("aprovado");
        
        
    }else{
    printf("reprovado");
    
    }
    return 0;
}
