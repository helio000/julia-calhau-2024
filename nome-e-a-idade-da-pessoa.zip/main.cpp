#include <stdio.h>

int main() {
    char nome[100];
    int idade;

    printf("Digite o nome: ");
    scanf("%s", nome);

    printf("Digite a idade: ");
    scanf("%d", &idade);

    if (idade >= 5) {
        printf("Adulto\n");
    } else {
        printf("Criança\n");
    }

    return 0;
}